module GitHub
  module Markup
    VERSION = '3.0.4'
    Version = VERSION
  end
end
